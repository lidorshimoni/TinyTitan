#ifndef _SYSFILE_H_
#define _SYSFILE_H_

#include <stdio.h>
#include <math.h>

#define ID 0

#define STEPMOTOR

#pragma used+
void SysInit(void);
void Delay(unsigned short t);
short ReadPos(unsigned char ucChannel);
unsigned int read_adc(unsigned char adc_input);
void WriteDO(unsigned char ucChanel,unsigned char ucData);
unsigned char ReadDI(unsigned char ucChanel);
void SetSteeringMotor(unsigned char ucChannel,signed short sPulsWidth,unsigned char ucIncriment);   /*ucChannel为舵机通道0～6，sPulsWidth对应舵机角度500~2500*/
void SetMotorSpeed (unsigned char ucChannel,char cTempSpeed,unsigned char ucIncriment);             /*ucChannel电机通道0~3，cSpeed为电机速度-100~100*/
void SetStepMotor(unsigned char ucChannel,short sStep,unsigned char ucIncriment) ;        /*ucChannel步进电机通道0~1，iStep步进步数-3000~3000*/
void SetStepCurrent (unsigned char ucChannel,unsigned char ucCurrent);
void SetStepSpeed (unsigned char ucChannel,unsigned char ucSpeed);
#pragma used-
#pragma library sysfile.lib
#endif
